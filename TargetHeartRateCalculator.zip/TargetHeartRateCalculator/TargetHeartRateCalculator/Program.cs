using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Tamer Ayoub

namespace TargetHeartRateCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your first name: ");
            var firstName = Console.ReadLine();

            Console.WriteLine("Enter your last name: ");
            var lastName = Console.ReadLine();

            Console.WriteLine("Enter your birth year: ");
            var yearOfBirth = Convert.ToInt32(Console.ReadLine());

            var heartRate = new HeartRate(firstName, lastName, yearOfBirth);

            Console.WriteLine("Your name is {0} {1}", heartRate.FirstName, heartRate.LastName);
            Console.WriteLine("Your age is {0}", heartRate.PersonAge);
            Console.WriteLine("Your max safe heart rate is {0}", heartRate.MaxHeartRate);
            Console.WriteLine("Your max target heart rate is {0}", heartRate.MaxTargetHeartRate);
            Console.WriteLine("Your min target heart rate is {0}", heartRate.MinTargetHeartRate);

            Console.ReadKey();
        }
    }
}
