﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TargetHeartRateCalculator
{
    class HeartRate
    {
        private string _firstName;
        private string _lastName;
        private int _yearOfBirth;

        public HeartRate(string firstName, string lastName, int yearOfBirth)
        {
            CurrentYear = DateTime.Today.Year;
            FirstName = firstName;
            LastName = lastName;
            YearOfBirth = yearOfBirth;
        }

        public string FirstName
        {
            get { return _firstName;}
            set { _firstName = value == "" ? "n/a" : value; }
        }

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value == "" ? "n/a" : value; }
     
        }

        public int YearOfBirth
        {
            get { return _yearOfBirth;}
            set { _yearOfBirth = value < 1 ? 0 : value; }
        }

        public readonly int CurrentYear;

        public int PersonAge
        {
            get { return CurrentYear - YearOfBirth; }
        }

        public int MaxHeartRate
        {
            get { return 220 - PersonAge; }
        }

        public int MinTargetHeartRate
        {
            get { return Convert.ToInt32(MaxHeartRate * 0.5); }
        }
        public int MaxTargetHeartRate
        {
            get { return Convert.ToInt32(MaxHeartRate * 0.85); }
        }
    }
}
